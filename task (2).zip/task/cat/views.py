from django.shortcuts import render,redirect
from cat.models import Empolye

# Create your views here.
def krish(request):
    d=Empolye.objects.all()
    if request.method=="POST":
        a=request.POST['v1']
        b= request.POST['v2']
        c=Empolye()
        c.EMP_NAME=a
        c.EMP_ADS=b
        c.save()
    return render(request,'first.html',{'f':d})
def sec(request,id):
    m=Empolye.objects.get(id=id)
    if request.method=="POST":
        a=request.POST['v1']
        b= request.POST['v2']
        m.EMP_NAME=a
        m.EMP_ADS=b
        m.save()
        return redirect('first')
    return render(request,'sec.html',{'x':m})
def dele(request,id):
    q=Empolye.objects.get(id=id)
    q.delete()
    return redirect('first')


