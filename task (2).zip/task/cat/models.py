from django.db import models

# Create your models here.
class Empolye(models.Model):
    EMP_NAME=models.CharField(max_length=200)
    EMP_ADS=models.CharField(max_length=200)
